import React from 'react';
import Button from '@mui/material/Button';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { connect } from 'react-redux';
import { getUser } from '../../redux/userSlice';
import { getProviderIcons } from '../common';
import { userType, providerIconsType, providersType } from '../../interfaces';
import './loginbuttons.scss';

export const mapStateToProps = ({ user }: {user: userType}) => ({ user });

const actionCreators = {
  getUser,
};

const handleLogin = (loc: string) => { // twitter/ google authentication
  window.location.assign(loc);
};

export function ProviderButton({ service }: {service: string}) {
  const providerIcons: providerIconsType = getProviderIcons({ fontSize: 25 });
  return (
    <Button
      id={`${service}loginbutton`}
      variant="outlined"
      startIcon={providerIcons[service as keyof providerIconsType].icon}
      onClick={() => handleLogin(`/auth/${service}`)}
      onMouseDown={(e) => e.preventDefault()}
    >
      {`Continue With ${service.charAt(0).toUpperCase() + service.slice(1)}`}
    </Button>
  );
}

interface LoginButtonsProps{
  user: userType
  getUser: (path: string) => void
  guest: () => void
}

export class LoginButtons extends React.Component<LoginButtonsProps> {

  handleGuest = () => { // set guest user
    const { getUser: setGuestStatus, guest } = this.props;
    setGuestStatus('/auth/guest');
    guest(); // callback to hid login div
  };

  render() {
    const { user: { providers, username } } = this.props;
    if (!providers) return null;
    const providerKeys = Object.keys(providers);
    return (
      <>
        {

          username !== 'Guest' && (
            <Button id="guestbutton" variant="outlined" startIcon={<AccountCircleIcon style={{ fontSize: 25 }} />} onClick={this.handleGuest}>
              Continue As Guest&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </Button>
          )
        }

        {
          providerKeys.map((service) => {
            if (providers[service as keyof providersType]) {
              return <ProviderButton key={service} service={service} />;
            }
            return null;
          })
        }
      </>
    );
  }

}

export default connect(mapStateToProps, actionCreators)(LoginButtons);
